'use strict';

angular.module('myApp.register_confirmation', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
 
}])

.controller('register_confirmationCtrl', [function() {

}]);